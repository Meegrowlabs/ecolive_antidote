<?php
/**
 * Fallback index — blog listing.
 *
 * @package ecolive-organic
 */
get_header();
get_template_part( 'template-parts/blog-listing' );
get_footer();
